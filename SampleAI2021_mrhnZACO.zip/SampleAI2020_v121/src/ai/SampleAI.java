/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ai;

import gameElements.Game;
import gameElements.GameResources;
import gui.ClientGUI;
import gui.MessageRecevable;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import network.ServerConnecter;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * サンプルのAI<br>
 *
 * ただただひたすらゼミに置き続けます。
 *
 * @author niwatakumi
 */
public class SampleAI extends LaboAI {

    // 自プレイヤーの名前
    protected String myName;
    // 自プレイヤーの番号
    protected int myNumber;
    // 相手プレイヤーの番号
    protected int enemyNumber;
    
    // コマ役割
    protected String chara[] = new String[4];
    protected String place[] = {"1-1", "2-1", "2-2", "3-1", "3-2", "3-3", "3-4",
                                "4-1", "4-2", "4-3", "4-4", "4-5", "5-1", "5-1",
                                "5-2", "5-3", "5-4", "5-5", "6-1", "6-2", "6-3"};
    protected String spend[] = {"", "F", "G", "M", "FF", "FG", "GG"};

    // サーバーとのコネクタ
    protected ServerConnecter connecter;
    // GUI
    protected ClientGUI gui;

    // 自分が何手打ったかを数える
    protected int handNum = 0;

    // 初期化が完了したか
    protected boolean isInitEnded = false;
    // 210 CONFPRMしたときに返ってくるメッセージを記録する
    protected ArrayList<String> confirmMessages = new ArrayList<>();

    /**
     * コンストラクタ＝初期化関数
     *
     * @param game
     */
    public SampleAI(Game game) {
        super(game);
        // 初期化時に設定する変数はここ
        this.myName = "你好AI[娘々]";
    }

    public String getMyName() {
        return this.myName;
    }

    /**
     * AIとサーバを接続するメソッド
     *
     * @param connecter
     */
    @Override
    public void setConnecter(ServerConnecter connecter) {
        // サーバに接続する
        this.connecter = connecter;
        this.connecter.addMessageRecever(this);
    }

    /**
     * GUIとAIを接続するメソッド
     *
     * @param mr
     */
    @Override
    public void setOutputInterface(MessageRecevable mr) {
        this.gui = (ClientGUI) mr;
    }

    /**
     * クライアント側のログにテキストを表示（緑）
     *
     * @param text
     */
    @Override
    public void addMessage(String text) {
        //属性情報を作成
        SimpleAttributeSet attribute = new SimpleAttributeSet();
        //属性情報の文字色に緑を設定
        attribute.addAttribute(StyleConstants.Foreground, Color.GREEN);

        // クライアント側のログに緑で表示
        this.gui.addMessage(text, attribute);
    }

    /**
     * サーバーにメッセージを送る
     *
     * @param sendText 送るメッセージ
     */
    public void sendMessage(String sendText) {
        //属性情報を作成
        SimpleAttributeSet attribute = new SimpleAttributeSet();
        //属性情報の文字色に赤を設定
        attribute.addAttribute(StyleConstants.Foreground, Color.RED);

        //サーバーへ送信
        if (this.connecter.canWrite()) {
            this.connecter.sendMessage(sendText);
            this.gui.addMessage("[send]" + sendText + "\n", attribute);
        } else {
            this.gui.addMessage("(送信失敗)" + sendText + "\n", attribute);
        }
    }

    /**
     * メッセージを受信した時のメソッド
     *
     * @param text
     */
    @Override
    public void reciveMessage(String text) {
        // 受信メッセージの最初の番号を確認する
        String messageNum = text.substring(0, 3);
        switch (messageNum) {
            case "100":
                // サーバーが応答した時
                this.helloServer();
                break;
            case "102":
                // サーバーからプレイヤー番号が返ってきた時
                this.checkNumber(text);
                break;
            case "103":
                // サーバーからキャラクターをセレクトするように言われたとき
                this.sendCharacters();
                break;
            case "204":
                // 盤面状態を確認
                this.sendMessage("210 CONFPRM");
                this.confirmMessages = new ArrayList<>();
                break;
            case "206":
                // 相手が打った時の処理
                break;
            case "207":
                // 季節が変わったらしい時は自分の仮想ゲームでも更新する
                this.changeSeason();
                break;
            case "211":
            case "212":
            case "213":
            case "214":
            case "215":
            case "216":
                // 210 CONFPRMしたときのメッセージ，記録する
                this.confirmMessages.add(text);
                break;
            case "202":
                // マルチラインの終了＝リソース情報取得終了
                // 仮想ゲームに反映する
//                System.out.println(this.confirmMessages);
                this.gameBoard = new Game(confirmMessages, this.myNumber);
                this.think();
                break;
            case "501":
                // 勝敗に合わせて重みを更新する
                double avr = 1.0;
//                for(int b=0; b<10; b++){
//                    for(int a=0; a<5; a++){
//                        avr += weight_update[b][a] / 100.0;
//                    }
//                }
                for(int b=0; b<2; b++){
                    for(int a=0; a<5; a++){
                        if(text.substring(11,12) == String.valueOf(this.enemyNumber)){
                            weight[b][a] += weight_update[b][a] * avr;
                        }else{
                            weight[b][a] -= weight_update[b][a] * avr;
                        }
                    }
                }
                write_weight("weight.txt", weight);
                System.out.println("Wrote!!");
                break;
        }
    }

    /**
     * サーバーが応答した時のメソッド
     */
    protected void helloServer() {
        // 名前を送る
        this.sendMessage("101 NAME " + this.myName);
    }

    /**
     * サーバーからプレイヤー番号が送られてきた時の処理
     *
     * @param text サーバーからのメッセージ
     */
    protected void checkNumber(String text) {
        // 番号を確認する
        this.myNumber = Integer.parseInt(text.substring(13));
        if (this.myNumber == 0) {
            this.enemyNumber = 1;
        } else {
            this.enemyNumber = 0;
        }
    }

    /**
     * サーバーからキャラクターを送るように言われたときのメソッド
     */
    protected void sendCharacters() {
        
        chara[0] = "E";
        chara[1] = "R";
        chara[2] = "S";
        
        // キャラクターを送る
        String message = "104 CHARACTER ";
        message += chara[0];
        message += " ";
        message += chara[1];
        this.sendMessage(message);
    }

    /**
     * コマを置くメソッド<br>
     * 引数の詳細は以下のリンクを確認してください。 <br>
     * https://lms.gifu-nct.ac.jp/pluginfile.php/68446/mod_resource/content/0/5E%E5%AE%9F%E9%A8%93%E3%83%97%E3%83%AD%E3%83%88%E3%82%B3%E3%83%AB%E8%AA%AC%E6%98%8E200410.pdf
     *
     * @param worker コマの種類
     * @param place 場所
     * @param option 場所に応じたオプション
     */
    private void putWorker(String worker, String place, String option) {
        if (this.gameBoard.canPutWorker(this.myNumber, place, worker, option)) {
            this.sendMessage("205 PLAY " + this.myNumber + " " + worker + " " + place + " " + option);
            this.gameBoard.play(this.myNumber, place, worker, option);
        } else {
            System.err.println("Put Error!!");
        }
    }

    /**
     * 仮想ゲームの季節を更新する
     */
    protected void changeSeason() {
        this.gameBoard.changeNewSeason();
        this.seasonChanged();
    }

    /**
     * 季節が変わった時に呼び出される関数
     */
    protected void seasonChanged() {
        // 手数をリセット
        this.handNum = 0;

        // 季節を取得
        Game currentGameBoard = this.gameBoard.clone();
        String season = currentGameBoard.getSeason();

        // もし"06"ならメッセージを表示
        if (season.equals("06")) {
            this.addMessage("=====折り返し！=====");
        }
    }
    
        /**
    * 手をシミュレートする
    * (季節はまたげないので注意)
    * @param nowGame 現在の盤面
    * @param player プレイヤー番号
    * @param worker 駒の種類
    * @param place 場所
    * @param option オプション
    * @return 打てる場合は打った後のゲーム盤面，打てない場合はnull
    */
    private Game simulateGame(Game nowGame, int player, String worker, String place, String option) {
        // ゲームを複製する（複製しないと大元のゲームデータが変更されてしまう）
        Game clonedGame = nowGame.clone();

        // 指定された手をうつことができるかをチェック
        if (clonedGame.canPutWorker(player, place, worker, option)) {
            // 打てるなら実際に打ってみたゲームデータを返却
            clonedGame.play(player, place, worker, option);
            return clonedGame;
        }
        else {
            // 打てないならnullを返す
            return null;
        }
    }
    
    

    
    /* 評価関数の重み.txtを読み込む */
    private double[][] read_weight(String fileName){
        double[][] weight = new double[10][5];
        try{
            File file = new File(fileName);
            FileReader filereader = new FileReader(file);
            BufferedReader br = new BufferedReader(filereader);
            String str = null;
            System.out.println("read_result...");
            int i=0,j=0;
            while((str = br.readLine()) != null){
                System.out.println(str);
                weight[j][i] = Double.parseDouble(str);
                i++;
                if(i>=5){
                    i=0;
                    j++;
                }
            }
            br.close();
        }catch(FileNotFoundException e){
            System.out.println(e);
        }catch(IOException e){
            System.out.println(e);
        }
        return weight;
    }
    
    /* 評価関数の重み.txtに書き込む */
    private void write_weight(String fileName, double[][] adjust){
        try{
            File file = new File(fileName);
            FileWriter filewriter = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(filewriter);
            PrintWriter pw = new PrintWriter(bw);
            for(int j=0; j < 2; j++){
                for(int i=0; i < 5; i++){
                    pw.println(String.valueOf(adjust[j][i]));
                }
            }
            pw.close();
        }catch(FileNotFoundException e){
            System.out.println(e);
        }catch(IOException e){
            System.out.println(e);
        }
    }
    
    // リソース影響配列
    private double influence[][] = {
        //ゼミ      図書館                   実験
        {1,1,1,0,0},{1,1,0,0,0},{0,1,0,0,0},{1,0,-1,0,0},{0,1,-1,0,0},
        //                          発表
        {1,1,-1.5,0,0},{1,1,-2,0,0},{-0.5,0,0,1,0.5},{0,-0.5,0,0.5,1},{0,-1,0,1,1},
        //                          論文
        {0,-2,0,1,2},{0,-1.5,2,1,0},{-1,-0.5,-0.5,1,2.5},{0,-2.5,-0.5,1,3},{-2.5,0,-0.5,1,3},
        //                               研究報告
        {-2,-2,-0.5,1,4},{-3,0,-0.5,1,5},{0,0,3,0,0},{-0.5,-0.5,1.5,0,0},{-1.5,0,2.5,0,0}
    };
    private double weight_update[][] = {{0,0,0,0,0},{0,0,0,0,0}};
    // 重みの取得
    private double[][] weight = read_weight("weight.txt");
    
    /**
     * 手を考えて打つ処理<br>
     * 基本的にはここをいじって思考させるといいと思います。
     */
    protected void think() {
        // 現在のゲームの状態はthis.gameBoradに入っています。
        // 上の方の処理で自動的にサーバーと同期する…はず
        // 色々試しに打ったりすることを考えると，cloneで複製しておくことをおすすめします．
        Game currentGameBoard = this.gameBoard.clone();

        // 試しに季節を取得。
        String season = currentGameBoard.getSeason();
        // GUIにログを書く場合はthis.addMessage(text)を利用
        // System.out.println()では表示されません。
        this.addMessage("現在の季節は" + season);

        // お金などのリソースはGameResourcesの中にあります。
        GameResources myResources = currentGameBoard.getResourcesOf(this.myNumber);
        GameResources enemyResources = currentGameBoard.getResourcesOf(this.enemyNumber);

        // 自分のリソースを取得→表示
        int myMoney = myResources.getCurrentMoney();
        int myFlask = myResources.getCurrentResrchPoint(0);
        int myGear = myResources.getCurrentResrchPoint(1);
        this.addMessage(myMoney + "円");
        this.addMessage(myFlask + "フラスコ");
        this.addMessage(myGear + "ギア");

        // 両者のスコアを取得
        int myScore = myResources.getTotalScore();
        int enemyScore = enemyResources.getTotalScore();
        // 比較してみる
        if (myScore > enemyScore) {
            this.addMessage((myScore - enemyScore) + "点勝っています");
        } else if (myScore == enemyScore) {
            this.addMessage("引き分けています");
        } else {
            this.addMessage((enemyScore - myScore) + "点負けています");
        }
        
        // 重みの取得
        //double[] weight = read_weight("weight.txt");
        //write_weight("weight.txt", /*ここに新しい重み配列*/);
        
        /* 
        ここに何らかの処理を入れるといいと思います。
        今回はゼミに置くだけ
         */
        String[] placement = new String[3];
        switch (season) {
            case "01":
            case "02":
            case "03":
            case "04":
            case "05":
                placement = evaluate(currentGameBoard, weight[0]);
                for(int l=0; l < 5; l++){
                    weight_update[0][l] += diff(currentGameBoard, placement)[l];
                }
                this.putWorker(placement[0], placement[1], placement[2]);
                break;
            case "06":
            case "07":
            case "08":
            case "09":
            case "10":
                placement = evaluate(currentGameBoard, weight[1]);
                for(int l=0; l < 5; l++){
                    weight_update[1][l] += diff(currentGameBoard, placement)[l];
                }
                this.putWorker(placement[0], placement[1], placement[2]);
                break;
        }

        // 手数をカウント
        this.handNum++;

    }
    
    // リソースの変化分を返す関数
    private double[] diff(Game currentGB, String[] place){
        double[] diff    = {0,0,0,0,0};
        Game simulatedGame = this.simulateGame(currentGB, this.myNumber, place[0], place[1], place[2]);
        GameResources currentMR = currentGB.getResourcesOf(this.myNumber);
        GameResources simulatedMR = simulatedGame.getResourcesOf(this.myNumber);
        diff[0] = simulatedMR.getCurrentResrchPoint(0) - currentMR.getCurrentResrchPoint(0);
        diff[1] = simulatedMR.getCurrentResrchPoint(1) - currentMR.getCurrentResrchPoint(1);
        diff[2] = simulatedMR.getCurrentMoney() - currentMR.getCurrentMoney();
        diff[3] = simulatedMR.getAchievementCount() - currentMR.getAchievementCount();
        diff[4] = simulatedMR.getTotalScore() - currentMR.getTotalScore();
        for(int w=0; w<5; w++){
            if(diff[w]  < 0)diff[w] = 0;
            if(diff[w] != 0)diff[w] = 0.005;
        }
        return diff;
    }
    
    // 盤面の評価関数β
    private String[] evaluate(Game currentGameBoard, double[] weight) {
        double evaluate_point;
        double max_profit = 0;
        String[] placement = new String[3];
        
        for(int actor=0; actor<3; actor++)
            for(int i=0; i < place.length; i++){
                for(int j=0; j < spend.length; j++){
                    Game simulatedGame = this.simulateGame(currentGameBoard, this.myNumber, chara[actor], place[i], spend[j]);
                    if(simulatedGame == null) {
                        // simulatedGameがnullなら置けなかったということ
                        this.addMessage(chara[actor]+"は"+place[i]+"に置けません！");
                    } else {
                        // シミュレートした後のリソースを取得
                        GameResources simulatedMyResources = simulatedGame.getResourcesOf(this.myNumber);
                        int simulatedScore = simulatedMyResources.getTotalScore();
                        // 得られたそれぞれのリソースに重みを掛けたものの総和を評価とする
                        evaluate_point =  weight[0] * simulatedMyResources.getCurrentResrchPoint(0)
                                        + weight[1] * simulatedMyResources.getCurrentResrchPoint(1)
                                        + weight[2] * simulatedMyResources.getCurrentMoney()
                                        + weight[3] * simulatedMyResources.getAchievementCount()
                                        + weight[4] * simulatedMyResources.getTotalScore();
                        if(evaluate_point > max_profit){
                            // 最も評価値の高いものを選ぶ
                            max_profit = evaluate_point;
                            placement[0] = chara[actor];
                            placement[1] = place[i];
                            placement[2] = spend[j];
                        }
                    }
                }
            }
        return placement;
    }
    
    
    /*
    private class Evlt {
        public String[] placement = new String[3];
        public int point;

        // コンストラクタ
        public Evlt(String[] placement, int point) {
            this.placement = placement;
            this.point = point;
        }
    }
    
    //先読みしたい関数 超えられない季節(2021.4.30)
    private Evlt Mypreload(Game currentGameBoard) {
        int evp = 0;
        int maxP = 0;
        int total = 0;
        String[] best = new String[3];
        Evlt evlt = new Evlt(best, 0);
        Evlt rcv;
        GameResources myResources = currentGameBoard.getResourcesOf(this.myNumber);
        ArrayList<String> workers = myResources.getUnusedWorkers();
        for(int a=0; a<workers.size(); a++)
            for(int i=0; i < place.length; i++){
                for(int j=0; j < spend.length; j++){
                    Game simulatedGame = this.simulateGame(currentGameBoard, this.myNumber, workers.get(a), place[i], spend[j]);
                    if(simulatedGame == null) {
                        // simulatedGameがnullなら置けなかったということ
                    } else {
                        myResources = simulatedGame.getResourcesOf(this.myNumber);
                        GameResources enemyResources = simulatedGame.getResourcesOf(this.enemyNumber);
                        if(myResources.getUnusedWorkers().isEmpty() && enemyResources.getUnusedWorkers().isEmpty()){
                            // シーズンの最後であるときに評価（おけるコマがない）
                            // 前の手につながる葉の評価を算出
                            evp = myResources.getCurrentResrchPoint(0)
                                + myResources.getCurrentResrchPoint(1)
                                + myResources.getCurrentMoney()
                                + myResources.getAchievementCount()
                                + 5*myResources.getTotalScore()
                                - enemyResources.getCurrentResrchPoint(0)
                                - enemyResources.getCurrentResrchPoint(1)
                                - enemyResources.getCurrentMoney()
                                - enemyResources.getAchievementCount()
                                - enemyResources.getTotalScore();
                            total += evp;
                            if(maxP < evp){
                                maxP = evp;
                                best[0] = workers.get(a);
                                best[1] = place[i];
                                best[2] = spend[j];
                                System.out.println(evp);
                            }
                        } else {
                            // まだこの後に置けるコマが残っているとき
                            // 今考えている手を打った時、そののちの全体の評価をもとに判断
                            rcv = this.Enpreload(simulatedGame);
                            if(maxP < rcv.point){
                                best[0] = workers.get(a);
                                best[1] = place[i];
                                best[2] = spend[j];
                                maxP = rcv.point;
                            }
                            total += rcv.point;
                        }
                    }
                }
            }
        evlt.point = total;
        evlt.placement = best;
        return evlt;
    }
    private Evlt Enpreload(Game currentGameBoard){
        int evp = 0;
        int maxP = 0;
        int total = 0;
        String[] best = new String[3];
        Evlt evlt = new Evlt(best, 0);
        Evlt rcv;
        GameResources enemyResources = currentGameBoard.getResourcesOf(this.enemyNumber);
        ArrayList<String> workers = enemyResources.getUnusedWorkers();
        for(int a=0; a<workers.size(); a++)
            for(int i=0; i < place.length; i++){
                for(int j=0; j < spend.length; j++){
                    Game simulatedGame = this.simulateGame(currentGameBoard, this.enemyNumber, workers.get(a), place[i], spend[j]);
                    if(simulatedGame == null) {
                        // simulatedGameがnullなら置けなかったということ
                    } else {
                        GameResources myResources = simulatedGame.getResourcesOf(this.myNumber);
                        enemyResources = simulatedGame.getResourcesOf(this.enemyNumber);
                        if(myResources.getUnusedWorkers().isEmpty() && enemyResources.getUnusedWorkers().isEmpty()){
                            // 評価して点数を考慮して手を決めたい
                            evp = myResources.getCurrentResrchPoint(0)
                                    + myResources.getCurrentResrchPoint(1)
                                    + myResources.getCurrentMoney()
                                    + myResources.getAchievementCount()
                                    + 5*myResources.getTotalScore()
                                    - enemyResources.getCurrentResrchPoint(0)
                                    - enemyResources.getCurrentResrchPoint(1)
                                    - enemyResources.getCurrentMoney()
                                    - enemyResources.getAchievementCount()
                                    - enemyResources.getTotalScore();
                            total += evp;
                            if(maxP < evp){
                                maxP = evp;
                                best[0] = workers.get(a);
                                best[1] = place[i];
                                best[2] = spend[j];
                                System.out.println(evp);
                            }
                        } else {
                            // まだこの後に置けるコマが残っているとき
                            // 今考えている手を打った時、そののちの全体の評価をもとに判断
                            rcv = this.Mypreload(simulatedGame);
                            if(maxP < rcv.point){
                                best[0] = workers.get(a);
                                best[1] = place[i];
                                best[2] = spend[j];
                                maxP = rcv.point;
                            }
                            total += rcv.point;
                        }
                    }
                }
            }
        evlt.point = total;
        evlt.placement = best;
        return evlt;
    }
    */
    
}
